/* This is a dummy <sys/string.h> used as a placeholder for
   systems that need to have a special header file.  */
